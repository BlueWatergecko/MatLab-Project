%{
Final Project Draft Code
Andrew J. Morin
3/28/2022
EGR - 115
%}
clear
clc

%Introducing User to code
fprintf('Welcome to Senior Shofer! \n')
fprintf('This program will help all seniors find a payemnt plan for their travel needs. \n')
fprintf('Please follow the instructions with each prompt to insure a swift and easy process! \n')
fprintf('If you are less than 60 years of age you cannot use our program. \n')
userName = input('Please input your first name here: \n','s');
userAge = input('Please input your age here: \n');

%Checking input validation and age requirment check
while (isempty(userAge) || userAge < 1 || userAge > 110 || mod(userAge,1) ~=0) %<SM:WHILE>
    fprintf('User Input Error! Please input a valid age. \n')
    userAge = input('Again, please input your age here: \n');
end

if userAge <  60 %<SM:IF> <SM:SWITCH>
    fprintf('Sorry but in order to use our system you must be 60 years or older! \n')
else
    fprintf('Congratulations %s! You are eligaible for Senior Shofer. \n',userName)
    fprintf('Now lets get started with finding you the best plan. \n')

%User input information into an array for code to have easy access
rowInput = input('Input how many weeks in a month you travel: \n');

while (isempty(rowInput) || rowInput < 1 || rowInput > 4 || mod(rowInput,1) ~=0) %<SM:ROP>
    fprintf('User Input Error! Please input a number 1 - 4! \n')
    rowInput = input('Again, input how many weeks in month you travel: \n');

end

colInput = input('Input how many days in a week do you travel: \n');

while (isempty(colInput) || colInput < 1 || colInput > 7 || mod(colInput,1) ~=0)  %<SM:BOP>
    fprintf('User Input Error! Please input a number 1 - 7! \n')
    colInput = input('Again, input how many days in a week you travel:  \n');
end

newMatrix = [];
fault = 0;
for row = 1:rowInput %<SM:FOR>
    
    for col = 1:colInput %<SM:NEST>
        fault = fault + 1;
    newMatrix(row,col) = input(sprintf('Enter the amount of miles travled for day %d: \n',fault));%<SM:STRING> %<SM:PDF_PARAM>

newMatrix(row,col) = UserMatrix_Validation(newMatrix(row,col));%<SM:PDF_RETURN> %<SM:PDF_PARAM> %<SM:CALL>

    end
end
fprintf('Now we need you Miles Per Gallon information on your car. \n')
mpgHigh = input('What is your vehcials miles per gallon high? \n');

while (isempty(mpgHigh) || mpgHigh > 55 || mpgHigh < 12 || mod(mpgHigh,1) ~=0)
    fprintf('User Input Error! Please enter in a proper mpg high vaule! \n')
    mpgHigh = input('Again what is your vehcials miles per gallon high? \n');
end

mpgLow = input('What is your vehcials miles per gallon low? \n');

while (isempty(mpgLow) || mpgLow < 11 || mpgLow > mpgHigh || mod(mpgLow,1) ~=0)
    fprintf('User Input Error! Please enter in a proper mpg low value! \n')
    mpgLow = input('Again, what is your vehcials miles per gallon low? \n');
end

%Calculations with user infromation
fprintf('Now that we have your travel infromation we will calculated your averages for you. \n')
fprintf('We are also including in possible gas prices to make sure that you will be able to afford our plan options. \n')
writematrix(newMatrix,'UserDriveData.xlsx') %<SM:NEWFUN> %<SM:WRTIE>
mpgMatrix = randi([mpgLow,mpgHigh],rowInput,colInput); %<SM:RANDUSE>
cpgMatrix = rand(rowInput,colInput)*(5-3) +3; %<SM:RANDGEN>

totalGas = newMatrix ./ mpgMatrix;
tripCost = totalGas .* cpgMatrix;

[rowSize,colSize] = size(tripCost);
totalCost = 0;

for y = 1:rowSize

    for x = 1:colSize   
   totalCost = totalCost + (tripCost(y,x)); %<SM:RTOTAL>
    end

end

sumDistance = sum(sum(newMatrix));
avgDistance = sumDistance / (colInput * rowInput);

%Information Accuary Check
fprintf('We have finished calculating the information required to give the proper plan, please check the information for accuracy. \n')
fprintf('Your average driving distance is %2.f miles in one month. \n',avgDistance)
fprintf('Your mpg High is %d and mpg Low is %d. \n',mpgHigh,mpgLow)
fprintf('You spend $%.2f on gas monthly. \n',totalCost)

inputAcu = input('Does all of this information look accurate to what you experience? (Yes = 1, No = 0) \n');

while (isempty(inputAcu) || inputAcu < 0 || inputAcu > 1 || mod(inputAcu,1) ~=0)
    fprintf('User Input Error! Please enter 1 for Yes and 0 for no!')
    inputAcu = input('Again, is all of this information look accurate to what you experience? (Yes = 1, No = 0) \n');
end

if inputAcu == 0
    fprintf('Alright we will have you input that information instead since our calculations are off. \n')
    avgDistance = input('Please input the average distance you travel a month: \n');

    while (isempty(avgDistance) || avgDistance < 1 || avgDistance > 200 || mod(avgDistance,1) ~=0)
        fprintf('User Input Error! Please input a proper value from 1 to 200! \n')
        avgDistance = input('Again, please input the average distance you travel a month: \n');
    end

    totalCost = input('Please input the average cost on gas you spend per month: \n');

    while (isempty(totalCost) || totalCost < 0 || totalCost > 300)
        fprintf('User Input Error! Please enter a value from 0 to 300!')
        totalCost = input('Again, please input the average cost on gas you spend per month: \n');
    end
        
else
    
end

%Finding a Plan for the User
fprintf('Alright lets get you a plan that suits your bugget and needs. \n')

if avgDistance <= 30 
    distanceLimit = 30;
elseif avgDistance > 30 && avgDistance <= 60
    distanceLimit = 60;
elseif avgDistance > 60 && avgDistance <= 90
    distanceLimit = 90;
elseif avgDistance > 90 && avgDistance <= 120
    distanceLimit = 120;
elseif avgDistance > 120 && avgDistance <= 150 && avgDistance > 150
    distanceLimit = 150;
end

if totalCost <= 20
    priceLimit = 20;
elseif totalCost > 20 && totalCost <= 40
    priceLimit = 40;
elseif totalCost > 40 && totalCost <= 60
    priceLimit = 60;
elseif totalCost > 60 && totalCost <=80
    priceLimit = 80;
elseif totalCost > 80 && totalCost <= 100 && totalCost > 100
    priceLimit = 100;
end


planData = readcell('PlanData_EGR115.xlsx'); %<SM:READ>
[rowSize2,colSize2] = size(planData); 

if distanceLimit == 30 && priceLimit == 20
    for i = 1:rowSize2
     if strcmp(planData(i,1),'Silver')%<SM:SEARCH> %<SM:REF>
         fprintf('The plan we suggest is %s with a monthly payment of $%d with \n a drive limit of %d times a month. \n',planData{i,1:3})
     end
    end

elseif distanceLimit == 60 && priceLimit == 40
    for i = 1:rowSize2
     if strcmp(planData(i,1),'Gold')
         fprintf('The plan we suggest is %s with a monthly payment of $%d with \n a drive limit of %d times a month. \n',planData{i,1:3})
     end
    end

elseif distanceLimit == 90 && priceLimit == 60
    for i = 1:rowSize2
     if strcmp(planData(i,1),'Platnium')
         fprintf('The plan we suggest is %s with a monthly payment of $%d with \n a drive limit of %d times a month. \n',planData{i,1:3})
     end
    end

elseif distanceLimit == 120 && priceLimit == 80
     for i = 1:rowSize2
     if strcmp(planData(i,1),'Dimoand')
         fprintf('The plan we suggest is %s with a monthly payment of $%d with \n a drive limit of %d times a month. \n',planData{i,1:3})
     end
    end

elseif distanceLimit == 150 && priceLimit == 100
     for i = 1:rowSize2
     if strcmp(planData(i,1),'Jade')
         fprintf('The plan we suggest is %s with a monthly payment of $%d with \n a drive limit of %d times a month. \n',planData{i,1:3})
     end
    end

else
    fprintf('Sorry either your information is not correct or information the user has input into the system is incorrect! \n')
end
planNames = planData(2:6,1); %<SM:SLICE>
fprintf('Here our other options if you are intrested %s, %s, %s, %s, and %s. \n',planNames{:})
fprintf('Thankyou for using Senior Shofer! \n')
fprintf('Have a great day and we hope your plan suits your needs, if not you can always come back to have it changed! \n')

%Bar Graph
nDays = colInput * rowInput;
day = [1:nDays];
miles = newMatrix;
bar(miles, 'r') %<SM:PLOT>
title('Drive Distance per Day Comparison')
xlabel('Day of each week')
ylabel('Miles Driven')

%End of Code




end
%RUBRIC LIST

%<SM:WHILE>  Line 19
%<SM:IF> Line 24
%<SM:SWITCH> Line 24
%<SM:ROP> Line 33
%<SM:BOP> Line 41
%<SM:FOR> Line 48
%<SM:NEST> Line 50
%<SM:STRING> Line 52
%<SM:PDF_PARAM> Line 54 & 52
%<SM:PDF_RETURN> Line 54 
%<SM:REF> Line 163
%<SM:RTOTAL> Line 89
%<SM:SEARCH> Line 163
%<SM:SLICE> Line 199
%<SM:NEWFUN> Line 76
%<SM:RANDUSE> Line 77
%<SM:RANDGEN> Line 78
%<SM:READ> Line 158
%<SM:WRITE> Line 76
%<SM:CALL> Line 54
%<SM:PLOT> Line 208

%SAMPLE RUN 
%{ 
Sample Run 1
Welcome to Senior Shofer! 
This program will help all seniors find a payemnt plan for their travel needs. 
Please follow the instructions with each prompt to insure a swift and easy process! 
Please input your first name here: 
Andrew
Please input your age here: 
78
Congratulations Andrew! You are eligaible for Senior Shofer. 
Now lets get started with finding you the best plan. 
Input how many weeks in a month you travel: 
2
Input how many days in a week do you travel: 
2
Enter the amount of miles travled for day 1: 
45
Enter the amount of miles travled for day 2: 
67
Enter the amount of miles travled for day 3: 
34
Enter the amount of miles travled for day 4: 
12
Now we need you Miles Per Gallon information on your car. 
What is your vehcials miles per gallon high? 
32
What is your vehcials miles per gallon low? 
16
Now that we have your travel infromation we will calculated your averages for you. 
We are also including in possible gas prices to make sure that you will be able to afford our plan options. 
We have finished calculating the information required to give the proper plan, please check the information for accuracy. 
Your average driving distance is 40 miles in one month. 
Your mpg High is 32 and mpg Low is 16. 
You spend $23.47 on gas monthly. 
Does all of this information look accurate to what you experience? (Yes = 1, No = 0) 
1
Alright lets get you a plan that suits your bugget and needs. 
The plan we suggest is Gold with a monthly payment of $40 with 
 a drive limit of 12 times a month. 
Here our other options if you are intrested Silver, Gold, Dimoand, Platnium, and Jade. /nThankyou for using Senior Shofer! 
Have a great day and we hope your plan suits your needs, if not you can always come back to have it changed! 

% Sample Run 2
Welcome to Senior Shofer! 
This program will help all seniors find a payemnt plan for their travel needs. 
Please follow the instructions with each prompt to insure a swift and easy process! 
If you are less than 60 years of age you cannot use our program. 
Please input your first name here: 
Andrew
Please input your age here: 
64
Congratulations Andrew! You are eligaible for Senior Shofer. 
Now lets get started with finding you the best plan. 
Input how many weeks in a month you travel: 
2
Input how many days in a week do you travel: 
2
Enter the amount of miles travled for day 1: 
34
Enter the amount of miles travled for day 2: 
23
Enter the amount of miles travled for day 3: 
56
Enter the amount of miles travled for day 4: 
34
Now we need you Miles Per Gallon information on your car. 
What is your vehcials miles per gallon high? 
28
What is your vehcials miles per gallon low? 
20
Now that we have your travel infromation we will calculated your averages for you. 
We are also including in possible gas prices to make sure that you will be able to afford our plan options. 
We have finished calculating the information required to give the proper plan, please check the information for accuracy. 
Your average driving distance is 37 miles in one month. 
Your mpg High is 28 and mpg Low is 20. 
You spend $24.10 on gas monthly. 
Does all of this information look accurate to what you experience? (Yes = 1, No = 0) 
1
Alright lets get you a plan that suits your bugget and needs. 
The plan we suggest is Gold with a monthly payment of $40 with 
 a drive limit of 12 times a month. 
Here our other options if you are intrested Silver, Gold, Dimoand, Platnium, and Jade. 
Thankyou for using Senior Shofer! 
Have a great day and we hope your plan suits your needs, if not you can always come back to have it changed! 

Sample Run 3
Welcome to Senior Shofer! 
This program will help all seniors find a payemnt plan for their travel needs. 
Please follow the instructions with each prompt to insure a swift and easy process! 
If you are less than 60 years of age you cannot use our program. 
Please input your first name here: 
Kass
Please input your age here: 
83
Congratulations Kass! You are eligaible for Senior Shofer. 
Now lets get started with finding you the best plan. 
Input how many weeks in a month you travel: 
5
User Input Error! Please input a number 1 - 4! 
Again, input how many weeks in month you travel: 
3
Input how many days in a week do you travel: 
4
Enter the amount of miles travled for day 1: 
34
Enter the amount of miles travled for day 2: 
23
Enter the amount of miles travled for day 3: 
56
Enter the amount of miles travled for day 4: 
45
Enter the amount of miles travled for day 5: 
34
Enter the amount of miles travled for day 6: 
23
Enter the amount of miles travled for day 7: 
67
Enter the amount of miles travled for day 8: 
45
Enter the amount of miles travled for day 9: 
23
Enter the amount of miles travled for day 10: 
45
Enter the amount of miles travled for day 11: 
34
Enter the amount of miles travled for day 12: 
23
Now we need you Miles Per Gallon information on your car. 
What is your vehcials miles per gallon high? 
30
What is your vehcials miles per gallon low? 
25
Now that we have your travel infromation we will calculated your averages for you. 
We are also including in possible gas prices to make sure that you will be able to afford our plan options. 
We have finished calculating the information required to give the proper plan, please check the information for accuracy. 
Your average driving distance is 38 miles in one month. 
Your mpg High is 30 and mpg Low is 25. 
You spend $63.95 on gas monthly. 
Does all of this information look accurate to what you experience? (Yes = 1, No = 0) 
1
Alright lets get you a plan that suits your bugget and needs. 
Sorry either your information is not correct or information the user has input into the system is incorrect! 
Here our other options if you are intrested Silver, Gold, Dimoand, Platnium, and Jade. 
Thankyou for using Senior Shofer! 
Have a great day and we hope your plan suits your needs, if not you can always come back to have it changed! 

%}

