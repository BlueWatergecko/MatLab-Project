function miles = UserMatrix_Validation(miles) %<SM:PDF> %<SM:PDF_PARAM>
% This function validates the user's input for the miles they drive each
% day in the array they have created.

while (isempty(miles) || miles < 0 || miles > 150 || mod(miles,1) ~=0)
    fprintf('Input error, please input a realistice number of miles for the distance! \n')
    miles = input('Again, enter the distance in miles: \n');
end

end